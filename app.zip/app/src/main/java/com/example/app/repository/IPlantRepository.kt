package com.example.app.repository

interface IPlantRepository {
}