package com.example.app.data.dao.models

enum class PlantType{
    ANNUALS, PERENNIALS, BIENNIALS
}