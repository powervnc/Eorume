package com.example.app.data.dao.models

enum class BloomTime{
    WINTER, SPRING, SUMMER, AUTUMN, VARIES
}